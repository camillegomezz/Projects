/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week4;
public class GradeCalculator 
{
    //private String name;
    //private int mark;
    
    public GradeCalculator()
    {
        
    }
       
    String calculateGrade(int mark)
    {
        if (mark<50)
            return "F";
        else if(mark<65)
            return "P";
        else if(mark<75)
            return "C";
        else if(mark<85)
            return "D";
        else
            return "HD";
    }    
}
