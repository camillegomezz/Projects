/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week4;
import java.util.*;

public class Test 
{
    public static void main(String[] args)
    {
        String name;
        int mark,hmark=Integer.MIN_VALUE,lmark=Integer.MAX_VALUE;
        double total=0;
        double avg;
        GradeCalculator gc=new GradeCalculator();
        Scanner input=new Scanner(System.in);
        
        for(int i=0;i<5;i++)
        {
            System.out.print("Enter Student name:");
            name=input.next();
            System.out.print("Enter Student mark:");
            mark=input.nextInt();
            
            //to check highest mark
            if(mark>hmark)
                hmark=mark;
            //end of to check highest mark
            
            //to check the lowest mark
            if(mark<lmark)
                lmark=mark;
            //end of to check the lowest mark
            
            System.out.printf("%s\t%d\t%s\n",name,mark,gc.calculateGrade(mark));
            total=total+mark;
        }
        System.out.printf("Average mark is %.2f", total/5);
        System.out.printf("Highest mark %d",hmark);
        System.out.printf("Lowest mark %d",lmark);
    }
    
}
